<?php echo e($slot); ?>

<?php /**PATH C:\Users\someO\Desktop\laravel\osboha-certificates-backend\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
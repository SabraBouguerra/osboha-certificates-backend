<?php echo e($slot); ?>

<?php /**PATH C:\Users\someO\Desktop\laravel\osboha-certificates-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>